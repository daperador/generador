package model.persistencia;

import model.persistencia.entity.*;
import java.util.List;
import java.util.ArrayList;
import javax.persistence.*;
import javax.ejb.Stateless;

/**
  *  @generated
  */
@Stateless
public class EstudianteDAO {
	@PersistenceContext
    private EntityManager em;

	
	/**
	* @generated
	*/
	public List<Estudiante> obtenerTodos(){
		return em.createNamedQuery("Estudiante.obtenerTodos").getResultList();
	}
	
	/**
	* @generated
	*/
	public Estudiante obtener(Long id){
		return em.find(Estudiante.class, id);
	}
	
	
	/**
	* @generated
	*/
	public Estudiante guardar(Estudiante entidad){
		em.persist(entidad);
		return entidad;
	}
	
	
	/**
	* @generated
	*/
	public void borrar(Long id){
		em.remove(em.find(Estudiante.class, id));
	}
	
	
	/**
	* @generated
	*/
	public void actualizar(Estudiante entidad){
		em.merge(entidad);
	}
	
	
}
