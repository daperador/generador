package model.persistencia.entity;


import java.util.List;
import java.util.ArrayList;
import javax.persistence.*;

/**
  *  @generated
  */
@Entity
@Table(name="Estudiante")//, schema="${schema}")
@NamedQueries({
	@NamedQuery(name="Estudiante.obtenerTodos", query="select e from Estudiante e")
})
public class Estudiante {

	@Id
    //@Column(name = "Estudiante_id")
    @GeneratedValue(generator = "EstudianteGen", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "EstudianteGen", sequenceName = "Estudiante_SEQ",allocationSize = 1)
	private Long id;

	public Long getId(){
		return this.id;
	}

	public void setId(Long id){
		this.id=id;
	}
    
    /**
    * @generated
    * 1-1-false
    */
    
    //@Column(name = "nombre")
    private String nombre;
    
    /**
    * @generated
    * 1-1-false
    */
    
    //@Column(name = "numeroDocumento")
    private String numeroDocumento;
    
    
    /**
    * @generated
    * 1-1-false
    */
    @ManyToOne(cascade={},fetch=FetchType.EAGER)
    private TipoDocumento tipoDocumento;
    
    /**
    * @generated
    * 0--1-true 
    */
    //@OneToMany(cascade={},fetch=javax.persistence.FetchType.LAZY)
    //private List<Seccion> secciones;
    
    
    /**
    * @generated
    */
    public String getNombre() {
        return this.nombre;
    }
    
    /**
    * @generated
    */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    /**
    * @generated
    */
    public String getNumeroDocumento() {
        return this.numeroDocumento;
    }
    
    /**
    * @generated
    */
    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }
    
	
	/*public List<Seccion> getSecciones(){
		if(secciones!=null){
			secciones=new ArrayList<Seccion>(); 
		}
		return this.secciones;
	}
	
	public void setSecciones(List<Seccion> secciones){
		this.secciones=secciones;
	}*/
	
	/**
	* @generated
	*/
	public TipoDocumento getTipoDocumento() {
	    return this.tipoDocumento;
	}
	
	/**
	* @generated
	*/
	public void setTipoDocumento(TipoDocumento tipoDocumento) {
	    this.tipoDocumento = tipoDocumento;
	}
	
}
