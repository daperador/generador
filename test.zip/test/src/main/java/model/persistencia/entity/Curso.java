package model.persistencia.entity;


import java.util.List;
import java.util.ArrayList;
import javax.persistence.*;

/**
  *  @generated
  */
@Entity
@Table(name="Curso")//, schema="${schema}")
@NamedQueries({
	@NamedQuery(name="Curso.obtenerTodos", query="select e from Curso e")
})
public class Curso {

	@Id
    //@Column(name = "Curso_id")
    @GeneratedValue(generator = "CursoGen", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "CursoGen", sequenceName = "Curso_SEQ",allocationSize = 1)
	private Long id;

	public Long getId(){
		return this.id;
	}

	public void setId(Long id){
		this.id=id;
	}
    
    /**
    * @generated
    * 1-1-false
    */
    
    //@Column(name = "nombre")
    private String nombre;
    
    
    /**
    * @generated
    * 0--1-true 
    */
    //@OneToMany(cascade={},fetch=javax.persistence.FetchType.LAZY)
    //private List<Seccion> secciones;
    
    
    /**
    * @generated
    */
    public String getNombre() {
        return this.nombre;
    }
    
    /**
    * @generated
    */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
	
	/*public List<Seccion> getSecciones(){
		if(secciones!=null){
			secciones=new ArrayList<Seccion>(); 
		}
		return this.secciones;
	}
	
	public void setSecciones(List<Seccion> secciones){
		this.secciones=secciones;
	}*/
	
}
