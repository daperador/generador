package model.persistencia.entity;


import java.util.List;
import java.util.ArrayList;
import javax.persistence.*;

/**
  *  @generated
  */
@Entity
@Table(name="Seccion")//, schema="${schema}")
@NamedQueries({
	@NamedQuery(name="Seccion.obtenerTodos", query="select e from Seccion e")
})
public class Seccion {

	@Id
    //@Column(name = "Seccion_id")
    @GeneratedValue(generator = "SeccionGen", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "SeccionGen", sequenceName = "Seccion_SEQ",allocationSize = 1)
	private Long id;

	public Long getId(){
		return this.id;
	}

	public void setId(Long id){
		this.id=id;
	}
    
    /**
    * @generated
    * 1-1-false
    */
    
    //@Column(name = "numero")
    private Integer numero;
    
    /**
    * @generated
    * 1-1-false
    */
    
    //@Column(name = "numeroMaxEstudiantes")
    private Integer numeroMaxEstudiantes;
    
    
    /**
    * @generated
    * 0--1-true 
    */
    //@OneToMany(cascade={},fetch=javax.persistence.FetchType.LAZY)
    //private List<Estudiante> estudiantes;
    
    /**
    * @generated
    * 0-1-false
    */
    @ManyToOne(cascade={},fetch=FetchType.EAGER)
    private Curso curso;
    
    
    /**
    * @generated
    */
    public Integer getNumero() {
        return this.numero;
    }
    
    /**
    * @generated
    */
    public void setNumero(Integer numero) {
        this.numero = numero;
    }
    
    /**
    * @generated
    */
    public Integer getNumeroMaxEstudiantes() {
        return this.numeroMaxEstudiantes;
    }
    
    /**
    * @generated
    */
    public void setNumeroMaxEstudiantes(Integer numeroMaxEstudiantes) {
        this.numeroMaxEstudiantes = numeroMaxEstudiantes;
    }
    
	
	/**
	* @generated
	*/
	public Curso getCurso() {
	    return this.curso;
	}
	
	/**
	* @generated
	*/
	public void setCurso(Curso curso) {
	    this.curso = curso;
	}
	
	/*public List<Estudiante> getEstudiantes(){
		if(estudiantes!=null){
			estudiantes=new ArrayList<Estudiante>(); 
		}
		return this.estudiantes;
	}
	
	public void setEstudiantes(List<Estudiante> estudiantes){
		this.estudiantes=estudiantes;
	}*/
	
}
