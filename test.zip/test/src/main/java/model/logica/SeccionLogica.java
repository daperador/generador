package model.logica;

import model.dto.*;
import model.persistencia.*;
import model.persistencia.entity.*;
import java.util.List;
import java.util.ArrayList;
import javax.persistence.*;
import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
  *  @generated
  */
@Stateless
public class SeccionLogica {
	@EJB
    private SeccionDAO persistencia;

	
	/**
	* @generated
	*/
	public List<SeccionDTO> obtenerTodos(){
		return convertirEntidad(persistencia.obtenerTodos());
	}
	
	/**
	* @generated
	*/
	public SeccionDTO obtener(Long id){
		return convertirEntidad(persistencia.obtener(id));
	}
	
	
	/**
	* @generated
	*/
	public SeccionDTO guardar(SeccionDTO dto){
		return convertirEntidad(persistencia.guardar(convertirDTO(dto)));
	}
	
	
	/**
	* @generated
	*/
	public void borrar(Long id){
		persistencia.borrar(id);
	}
	
	
	/**
	* @generated
	*/
	public void actualizar(SeccionDTO dto){
		persistencia.actualizar(convertirDTO(dto));
	}
	
	
	/**
	* @generated
	*/
	private Seccion convertirDTO(SeccionDTO dto){
		if(dto==null)return null;
		Seccion entidad=new Seccion();
		entidad.setId(dto.getId());
			entidad.setNumero(dto.getNumero());
			entidad.setNumeroMaxEstudiantes(dto.getNumeroMaxEstudiantes());
		
		return entidad;
	}
	
	
	/**
	* @generated
	*/
	private List<Seccion> convertirDTO(List<SeccionDTO> dtos){
		List<Seccion> entidades=new ArrayList<Seccion>();
		for(SeccionDTO dto:dtos){
			entidades.add(convertirDTO(dto));
		}
		return entidades;
	}
	
	
	/**
	* @generated
	*/
	private SeccionDTO convertirEntidad(Seccion entidad){
		SeccionDTO dto=new SeccionDTO();
		dto.setId(entidad.getId());
			dto.setNumero(entidad.getNumero());
			dto.setNumeroMaxEstudiantes(entidad.getNumeroMaxEstudiantes());
		
		return dto;
	}
	
	
	/**
	* @generated
	*/
	private List<SeccionDTO> convertirEntidad(List<Seccion> entidades){
		List<SeccionDTO> dtos=new ArrayList<SeccionDTO>();
		for(Seccion entidad:entidades){
			dtos.add(convertirEntidad(entidad));
		}
		return dtos;
	}
	
	
}
