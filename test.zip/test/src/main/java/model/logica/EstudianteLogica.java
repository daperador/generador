package model.logica;

import model.dto.*;
import model.persistencia.*;
import model.persistencia.entity.*;
import java.util.List;
import java.util.ArrayList;
import javax.persistence.*;
import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
  *  @generated
  */
@Stateless
public class EstudianteLogica {
	@EJB
    private EstudianteDAO persistencia;

	
	/**
	* @generated
	*/
	public List<EstudianteDTO> obtenerTodos(){
		return convertirEntidad(persistencia.obtenerTodos());
	}
	
	/**
	* @generated
	*/
	public EstudianteDTO obtener(Long id){
		return convertirEntidad(persistencia.obtener(id));
	}
	
	
	/**
	* @generated
	*/
	public EstudianteDTO guardar(EstudianteDTO dto){
		return convertirEntidad(persistencia.guardar(convertirDTO(dto)));
	}
	
	
	/**
	* @generated
	*/
	public void borrar(Long id){
		persistencia.borrar(id);
	}
	
	
	/**
	* @generated
	*/
	public void actualizar(EstudianteDTO dto){
		persistencia.actualizar(convertirDTO(dto));
	}
	
	
	/**
	* @generated
	*/
	private Estudiante convertirDTO(EstudianteDTO dto){
		if(dto==null)return null;
		Estudiante entidad=new Estudiante();
		entidad.setId(dto.getId());
			entidad.setNombre(dto.getNombre());
			entidad.setNumeroDocumento(dto.getNumeroDocumento());
		
		return entidad;
	}
	
	
	/**
	* @generated
	*/
	private List<Estudiante> convertirDTO(List<EstudianteDTO> dtos){
		List<Estudiante> entidades=new ArrayList<Estudiante>();
		for(EstudianteDTO dto:dtos){
			entidades.add(convertirDTO(dto));
		}
		return entidades;
	}
	
	
	/**
	* @generated
	*/
	private EstudianteDTO convertirEntidad(Estudiante entidad){
		EstudianteDTO dto=new EstudianteDTO();
		dto.setId(entidad.getId());
			dto.setNombre(entidad.getNombre());
			dto.setNumeroDocumento(entidad.getNumeroDocumento());
		
		return dto;
	}
	
	
	/**
	* @generated
	*/
	private List<EstudianteDTO> convertirEntidad(List<Estudiante> entidades){
		List<EstudianteDTO> dtos=new ArrayList<EstudianteDTO>();
		for(Estudiante entidad:entidades){
			dtos.add(convertirEntidad(entidad));
		}
		return dtos;
	}
	
	
}
