package model.logica;

import model.dto.*;
import model.persistencia.*;
import model.persistencia.entity.*;
import java.util.List;
import java.util.ArrayList;
import javax.persistence.*;
import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
  *  @generated
  */
@Stateless
public class CursoLogica {
	@EJB
    private CursoDAO persistencia;

	
	/**
	* @generated
	*/
	public List<CursoDTO> obtenerTodos(){
		return convertirEntidad(persistencia.obtenerTodos());
	}
	
	/**
	* @generated
	*/
	public CursoDTO obtener(Long id){
		return convertirEntidad(persistencia.obtener(id));
	}
	
	
	/**
	* @generated
	*/
	public CursoDTO guardar(CursoDTO dto){
		return convertirEntidad(persistencia.guardar(convertirDTO(dto)));
	}
	
	
	/**
	* @generated
	*/
	public void borrar(Long id){
		persistencia.borrar(id);
	}
	
	
	/**
	* @generated
	*/
	public void actualizar(CursoDTO dto){
		persistencia.actualizar(convertirDTO(dto));
	}
	
	
	/**
	* @generated
	*/
	private Curso convertirDTO(CursoDTO dto){
		if(dto==null)return null;
		Curso entidad=new Curso();
		entidad.setId(dto.getId());
			entidad.setNombre(dto.getNombre());
		
		return entidad;
	}
	
	
	/**
	* @generated
	*/
	private List<Curso> convertirDTO(List<CursoDTO> dtos){
		List<Curso> entidades=new ArrayList<Curso>();
		for(CursoDTO dto:dtos){
			entidades.add(convertirDTO(dto));
		}
		return entidades;
	}
	
	
	/**
	* @generated
	*/
	private CursoDTO convertirEntidad(Curso entidad){
		CursoDTO dto=new CursoDTO();
		dto.setId(entidad.getId());
			dto.setNombre(entidad.getNombre());
		
		return dto;
	}
	
	
	/**
	* @generated
	*/
	private List<CursoDTO> convertirEntidad(List<Curso> entidades){
		List<CursoDTO> dtos=new ArrayList<CursoDTO>();
		for(Curso entidad:entidades){
			dtos.add(convertirEntidad(entidad));
		}
		return dtos;
	}
	
	
}
