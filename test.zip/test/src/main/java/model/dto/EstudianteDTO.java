package model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import java.util.ArrayList;

/**
* @generated
*/
@JsonIgnoreProperties(ignoreUnknown = true)
public class EstudianteDTO {

	private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
	
    
    /**
    * @generated
    */
    private String nombre;
    
    
    /**
    * @generated
    */
    private String numeroDocumento;
    
    
    
    /**
    * @generated
    */
    private SeccionDTO secciones;
    
    /**
    * @generated
    */
    private TipoDocumentoDTO tipoDocumento;
    
    /**
    * @generated
    */
    public String getNombre() {
        return this.nombre;
    }
    
    /**
    * @generated
    */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    /**
    * @generated
    */
    public String getNumeroDocumento() {
        return this.numeroDocumento;
    }
    
    /**
    * @generated
    */
    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }
    
	/**
	* @generated
	*/
	public SeccionDTO getSecciones() {
	    return this.secciones;
	}
	
	/**
	* @generated
	*/
	public void setSecciones(SeccionDTO secciones) {
	    this.secciones = secciones;
	}
	/**
	* @generated
	*/
	public TipoDocumentoDTO getTipoDocumento() {
	    return this.tipoDocumento;
	}
	
	/**
	* @generated
	*/
	public void setTipoDocumento(TipoDocumentoDTO tipoDocumento) {
	    this.tipoDocumento = tipoDocumento;
	}
	
}
