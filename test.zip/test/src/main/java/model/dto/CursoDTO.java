package model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import java.util.ArrayList;

/**
* @generated
*/
@JsonIgnoreProperties(ignoreUnknown = true)
public class CursoDTO {

	private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
	
    
    /**
    * @generated
    */
    private String nombre;
    
    
    
    /**
    * @generated
    */
    private SeccionDTO secciones;
    
    /**
    * @generated
    */
    public String getNombre() {
        return this.nombre;
    }
    
    /**
    * @generated
    */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
	/**
	* @generated
	*/
	public SeccionDTO getSecciones() {
	    return this.secciones;
	}
	
	/**
	* @generated
	*/
	public void setSecciones(SeccionDTO secciones) {
	    this.secciones = secciones;
	}
	
}
