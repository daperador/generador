package model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import java.util.ArrayList;

/**
* @generated
*/
@JsonIgnoreProperties(ignoreUnknown = true)
public class SeccionDTO {

	private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
	
    
    /**
    * @generated
    */
    private Integer numero;
    
    
    /**
    * @generated
    */
    private Integer numeroMaxEstudiantes;
    
    
    
    /**
    * @generated
    */
    private EstudianteDTO estudiantes;
    
    /**
    * @generated
    */
    private CursoDTO curso;
    
    /**
    * @generated
    */
    public Integer getNumero() {
        return this.numero;
    }
    
    /**
    * @generated
    */
    public void setNumero(Integer numero) {
        this.numero = numero;
    }
    /**
    * @generated
    */
    public Integer getNumeroMaxEstudiantes() {
        return this.numeroMaxEstudiantes;
    }
    
    /**
    * @generated
    */
    public void setNumeroMaxEstudiantes(Integer numeroMaxEstudiantes) {
        this.numeroMaxEstudiantes = numeroMaxEstudiantes;
    }
    
	/**
	* @generated
	*/
	public EstudianteDTO getEstudiantes() {
	    return this.estudiantes;
	}
	
	/**
	* @generated
	*/
	public void setEstudiantes(EstudianteDTO estudiantes) {
	    this.estudiantes = estudiantes;
	}
	/**
	* @generated
	*/
	public CursoDTO getCurso() {
	    return this.curso;
	}
	
	/**
	* @generated
	*/
	public void setCurso(CursoDTO curso) {
	    this.curso = curso;
	}
	
}
