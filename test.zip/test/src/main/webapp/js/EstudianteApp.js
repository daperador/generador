'use strict';


// Declare app level module which depends on filters, and services
var module=angular.module('adminEstudiante', [
  'ngRoute',
  'adminEstudiante.controllers'
]);
module.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/', {templateUrl: 'partials/Estudiante.html', controller: 'EstudianteCtrl'});
  $routeProvider.otherwise({redirectTo: '/'}); 
}]);
